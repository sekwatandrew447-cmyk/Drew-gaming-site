# Gaming Portfolio Website

## Run locally

```bash
npm install
npm run dev
```

## Deploy

Upload to GitHub and deploy with Vercel.
